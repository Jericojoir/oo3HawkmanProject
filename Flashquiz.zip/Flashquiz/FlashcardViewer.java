import acm.graphics.*;
import acm.program.*;

public class FlashcardViewer extends GraphicsProgram {
    private static final int CARD_WIDTH = 400;
    private static final int CARD_HEIGHT = 200;

    public static void displayFlashcard(Flashcard flashcard) {
        FlashcardViewer viewer = new FlashcardViewer();
        viewer.showFlashcard(flashcard);
    }

    public void showFlashcard(Flashcard flashcard) {
        removeAll();

        GRect card = new GRect(CARD_WIDTH, CARD_HEIGHT);
        card.setFilled(true);
        card.setColor(java.awt.Color.WHITE);
        add(card, (getWidth() - CARD_WIDTH) / 2, (getHeight() - CARD_HEIGHT) / 2);

        GLabel questionLabel = new GLabel(flashcard.getQuestion());
        questionLabel.setFont("Helvetica-24");
        add(questionLabel, getWidth() / 2 - questionLabel.getWidth() / 2, getHeight() / 2 - 20);

        pause(1000); // Wait for 1 second to display the question

        String userAnswer = readLine("Answer: ");

        if (flashcard.getAnswer().equalsIgnoreCase(userAnswer)) {
            System.out.println("Correct!");
        } else {
            System.out.println("Incorrect! The correct answer was: " + flashcard.getAnswer());
        }
    }
}
