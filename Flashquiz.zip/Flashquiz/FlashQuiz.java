import acm.graphics.*;
import acm.program.*;
import javax.swing.*;
import java.io.*;
import java.util.*;

public class FlashQuiz extends GraphicsProgram {
    private List<Flashcard> flashcards;
    private Map<String, Integer> userScores;

    public FlashQuiz() {
        flashcards = new ArrayList<>();
        userScores = new HashMap<>();
    }

    public void addFlashcard() {
        String question = JOptionPane.showInputDialog("Enter the question:");
        String answer = JOptionPane.showInputDialog("Enter the answer:");

        Flashcard flashcard = new Flashcard(question, answer);
        flashcards.add(flashcard);
        JOptionPane.showMessageDialog(null, "Flashcard added!");
    }

    public void startQuizWithGraphics() {
        if (flashcards.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No flashcards available. Please add flashcards before starting the quiz.");
            return;
        }

        int totalQuestions = flashcards.size();
        int currentIndex = 0;
        int score = 0;

        while (currentIndex < totalQuestions) {
            Flashcard flashcard = flashcards.get(currentIndex);

            // Display the flashcard question
            JOptionPane.showMessageDialog(null, "Question: " + flashcard.getQuestion());

            String userAnswer = JOptionPane.showInputDialog("Answer:");

            if (flashcard.getAnswer().equalsIgnoreCase(userAnswer)) {
                JOptionPane.showMessageDialog(null, "Correct!");
                score++;
            } else {
                JOptionPane.showMessageDialog(null, "Incorrect! The correct answer was: " + flashcard.getAnswer());
            }

            removeAll(); // Remove the flashcard from the screen before moving to the next question
            pause(1000); // Wait for 1 second to display the answer

            currentIndex++;
        }

        double percentage = (double) score / totalQuestions * 100;
        String userName = JOptionPane.showInputDialog("Enter your name:");

        userScores.put(userName, score);

        JOptionPane.showMessageDialog(null, "Quiz completed, " + userName + "! Your score: " + score + "/" + totalQuestions + " (" + percentage + "%)");
    }

    private void showFlashcardQuestion(Flashcard flashcard) {
        GRect card = new GRect(400, 200);
        card.setFilled(true);
        card.setColor(java.awt.Color.WHITE);
        add(card, (getWidth() - 400) / 2, (getHeight() - 200) / 2);

        GLabel questionLabel = new GLabel("Question: " + flashcard.getQuestion());
        questionLabel.setFont("Helvetica-24");
        double x = (getWidth() - questionLabel.getWidth()) / 2;
        double y = (getHeight() - questionLabel.getHeight()) / 2;
        add(questionLabel, x, y - 25);
    }

    public void scoreboard() {
        StringBuilder scoreboardMsg = new StringBuilder("===== Scoreboard =====\n");
        if (userScores.isEmpty()) {
            scoreboardMsg.append("No scores to display.\n");
        } else {
            // Sort the users by their scores in descending order
            List<Map.Entry<String, Integer>> sortedScores = new ArrayList<>(userScores.entrySet());
            sortedScores.sort(Map.Entry.<String, Integer>comparingByValue().reversed());

            int rank = 1;
            for (Map.Entry<String, Integer> entry : sortedScores) {
                scoreboardMsg.append(rank).append(". ").append(entry.getKey()).append(": ").append(entry.getValue()).append(" points\n");
                rank++;

                // Show the top 5 scorers
                if (rank > 5) {
                    break;
                }
            }
        }
        scoreboardMsg.append("======================");
        JOptionPane.showMessageDialog(null, scoreboardMsg);
    }

    public void saveFlashcardsToFile(String filename) {
        try (PrintWriter writer = new PrintWriter(new FileWriter(filename))) {
            for (Flashcard flashcard : flashcards) {
                writer.println(flashcard.getQuestion() + "|" + flashcard.getAnswer());
            }
            JOptionPane.showMessageDialog(null, "Flashcards saved to " + filename);
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error saving flashcards to file: " + e.getMessage());
        }
    }

    public void loadFlashcardsFromFile() {
        String filename = JOptionPane.showInputDialog("Enter the filename to load flashcards:");

        try (Scanner fileScanner = new Scanner(new File(filename))) {
            flashcards.clear(); // Clear existing flashcards before loading new ones

            while (fileScanner.hasNextLine()) {
                String line = fileScanner.nextLine();
                String[] parts = line.split("\\|");
                if (parts.length == 2) {
                    String question = parts[0];
                    String answer = parts[1];
                    Flashcard flashcard = new Flashcard(question, answer);
                    flashcards.add(flashcard);
                }
            }

            JOptionPane.showMessageDialog(null, "Flashcards loaded from " + filename);
        } catch (FileNotFoundException e) {
            JOptionPane.showMessageDialog(null, "File not found: " + filename);
        }
    }

    public static void main(String[] args) {
        FlashQuiz quiz = new FlashQuiz();

        while (true) {
            String choice = JOptionPane.showInputDialog(
                    "Choose an option:\n" +
                            "1. Add flashcard\n" +
                            "2. Save FlashCards to file\n" +
                            "3. Load Flashcards from file \n" +
                            "4. Start quiz\n" +
                            "5. Show Scoreboard\n" +
                            "6. Exit"
            );

            switch (choice) {
                case "1":
                    quiz.addFlashcard();
                    break;
                case "4":
                    quiz.startQuizWithGraphics();
                    break;
                case "5":
                    quiz.scoreboard();
                    break;
                case "6":
                    JOptionPane.showMessageDialog(null, "Exiting the program. Goodbye!");
                    System.exit(0);
                    break;
                case "2":
                    String filenameToSave = JOptionPane.showInputDialog("Enter the filename to save the flashcards:");
                    quiz.saveFlashcardsToFile(filenameToSave);
                    break;
                case "3":
                    quiz.loadFlashcardsFromFile();
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "Invalid choice. Please try again.");
            }
        }
    }
}

